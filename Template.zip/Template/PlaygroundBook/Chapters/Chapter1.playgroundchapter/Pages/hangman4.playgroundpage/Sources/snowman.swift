import SceneKit
//public func addBall1() -> SCNNode {
//    let box = SCNBox(width: 0.2, height: 0.2, length: 0.2, chamferRadius: 0.1)
//    
//    let boxNode = SCNNode()
//    boxNode.geometry = box
////    boxNode.geometry?.firstMaterial?.diffuse.contents = #imageLiteral(resourceName: "snow.png")
//    boxNode.geometry?.firstMaterial?.diffuse.contents = UIColor(white: 1, alpha: 0)
//    boxNode.position = SCNVector3(0, 0, -0.2)
//    
//    return boxNode
//}

//public func addBall2() -> SCNNode {
//    let box = SCNBox(width: 0.15, height: 0.15, length: 0.15, chamferRadius: 0.75)
//    
//    let boxNode = SCNNode()
//    boxNode.geometry = box
//    boxNode.geometry?.firstMaterial?.diffuse.contents = UIColor.red
//    boxNode.position = SCNVector3(0, 0.1, -0.2)
//    
//    return boxNode
//}
//
//public func addBall3() -> SCNNode {
//    let box = SCNBox(width: 0.1, height: 0.1, length: 0.1, chamferRadius: 0.5)
//    
//    let boxNode = SCNNode()
//    boxNode.geometry = box
//    boxNode.geometry?.firstMaterial?.diffuse.contents = UIColor.green
//    boxNode.position = SCNVector3(0, 0.2, -0.2)
//    
//    return boxNode
//}

//public func addeye1() -> SCNNode {
//    let box = SCNBox(width: 0.005, height: 0.005, length: 0.005, chamferRadius: 0.0025)
//
//    let boxNode = SCNNode()
//    boxNode.geometry = box
//    boxNode.geometry?.firstMaterial?.diffuse.contents = UIColor.black
//    boxNode.position = SCNVector3(0, 0.2, -0.1495)
//
//    return boxNode
//}

//public func addeye2() -> SCNNode {
//    let box = SCNBox(width: 0.005, height: 0.005, length: 0.005, chamferRadius: 0.0025)
//    
//    let boxNode = SCNNode()
//    boxNode.geometry = box
//    boxNode.geometry?.firstMaterial?.diffuse.contents = UIColor.black
//    boxNode.position = SCNVector3(0.03, 0.2, -0.16)
//    
//    return boxNode
//}

//public func addNose() -> SCNNode {
////    let box = SCNBox(width: 0.005, height: 0.005, length: 0.005, chamferRadius: 0.0025)
//    let cap = SCNCapsule(capRadius: 0.003, height: 0.05)
//    
//    let capNode = SCNNode()
//    capNode.geometry = cap
//    capNode.geometry?.firstMaterial?.diffuse.contents = UIColor.blue
//    capNode.pivot = SCNMatrix4MakeRotation(Float(Double.pi / 2), 1, 0, -0.5)
//    capNode.position = SCNVector3(0.014, 0.19, -0.155)
//    
//    return capNode
//}

//public func addArm1() -> SCNNode {
//    //    let box = SCNBox(width: 0.005, height: 0.005, length: 0.005, chamferRadius: 0.0025)
//    let cap = SCNCapsule(capRadius: 0.005, height: 0.1)
//    
//    let capNode = SCNNode()
//    capNode.geometry = cap
//    capNode.geometry?.firstMaterial?.diffuse.contents = UIColor.brown
//    capNode.pivot = SCNMatrix4MakeRotation(Float(Double.pi / 2), 0.5, 0.5, 0.5)
////    capNode.position = SCNVector3(0.014, 0.095, -0.2)
//    capNode.position = SCNVector3(0.104, 0.095, -0.2)
//    return capNode
//}
//
//public func addArm2() -> SCNNode {
//    //    let box = SCNBox(width: 0.005, height: 0.005, length: 0.005, chamferRadius: 0.0025)
//    let cap = SCNCapsule(capRadius: 0.005, height: 0.1)
//    
//    let capNode = SCNNode()
//    capNode.geometry = cap
//    capNode.geometry?.firstMaterial?.diffuse.contents = UIColor.brown
//    capNode.pivot = SCNMatrix4MakeRotation(Float(Double.pi / 2), 0.5, -0.5, -0.5)
//    //    capNode.position = SCNVector3(0.014, 0.095, -0.2)
//    capNode.position = SCNVector3(-0.104, 0.095, -0.2)
//    return capNode
//}
